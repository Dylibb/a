#pragma once

//    
// PUBGM 4.2.0 iOS
// 分享: - @lubaiios 
// 生成时间 2026年01月06日 16时15分16秒
namespace SDK
{
//---------------------By lubaiios @LBAsTool---------------------------
//Script Structs
//---------------------By lubaiios @LBAsTool---------------------------

// UserDefinedStruct BP_STRUCT_CorpsBadge_type.BP_STRUCT_CorpsBadge_type
// 0x0040
struct FBP_STRUCT_CorpsBadge_type
{
	struct FString                                     BigIconPath_0_10CC26002C2272C4426923F90B6405C8;           // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_5727FF4053D9C66568AE85A909693024;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     IconPath_2_038F818050E2694643DA924F014A58A8;              // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Name_3_56563C4042608BF33377F2DB0931BF55;                  // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TabPosi_4_17AFE880638188BE77062DBF05E20589;               // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                UnLockLv_5_04857F8051FE2B7A53B16D630C5CAF66;              // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

