#pragma once

//    
// PUBGM 4.2.0 iOS
// 分享: - @lubaiios 
// 生成时间 2026年01月06日 16时15分18秒
namespace SDK
{
//---------------------By lubaiios @LBAsTool---------------------------
//Script Structs
//---------------------By lubaiios @LBAsTool---------------------------

// UserDefinedStruct ItemRecordData7.ItemRecordData7
// 0x0013
struct FItemRecordData7
{
	int                                                ItemType_2_CC000069486107946E5ECAAF21EFAF0B;              // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                WeightforOrder_4_E72E5D4C4B2B91B238136B89316C7DEF;        // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              UnitWeight_f_7_1AEC4D7B4F3AC4894A33FBAAC0165559;          // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxCount_10_ADC2EE5A44ABBCF4C00515AB724AD5AA;             // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               AutoEquipandDrop_13_CC1AD656453F2BAB5FCB9586C6793874;     // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Consumable_15_B2094A1644FCC44D1EBC08B3D9578342;           // 0x0011(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Equippable_17_D54B5E3C4807D350ED7429BF09AAB7D1;           // 0x0012(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

