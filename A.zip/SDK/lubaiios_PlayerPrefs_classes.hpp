#pragma once

//    
// PUBGM 4.2.0 iOS
// 分享: - @lubaiios 
// 生成时间 2026年01月06日 16时15分15秒
namespace SDK
{
//---------------------By lubaiios @LBAsTool---------------------------
//Classes
//---------------------By lubaiios @LBAsTool---------------------------

// BlueprintGeneratedClass PlayerPrefs.PlayerPrefs_C
// 0x0528 (0x0550 - 0x0028)
class UPlayerPrefs_C : public USaveGame
{
public:
	int                                                LoginCount;                                               // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                LoginTime;                                                // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               FirstInLobby;                                             // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               GuestWarningAccepted;                                     // 0x0031(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0032(0x0002) MISSED OFFSET
	int                                                YXXYRedPoint;                                             // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TArray<struct FString>                             NearByNewTipsList;                                        // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData01[0x50];                                      // 0x0048(0x0050) UNKNOWN PROPERTY: SetProperty PlayerPrefs.PlayerPrefs_C.CloseLocationList
	bool                                               QuestionDone;                                             // 0x0098(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               ServerListClicked;                                        // 0x0099(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x009A(0x0002) MISSED OFFSET
	int                                                MysteryLastTime;                                          // 0x009C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               notFirstEnterMall;                                        // 0x00A0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x00A1(0x0003) MISSED OFFSET
	int                                                CoprsShopLevelRedPoint;                                   // 0x00A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TArray<int>                                        StoreBoxList;                                             // 0x00A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<int, bool>                                    HasSeeShopItemDict;                                       // 0x00B8(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	int                                                LobbyNoticeID;                                            // 0x0108(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                UserAgreementAcceptedVersion;                             // 0x010C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                PrivacyPolicyAcceptedVersion;                             // 0x0110(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                ClickTimeNotBind;                                         // 0x0114(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                ClickTimeBind;                                            // 0x0118(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData04[0x4];                                       // 0x011C(0x0004) MISSED OFFSET
	TArray<int>                                        StoreGiftBoxList;                                         // 0x0120(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	bool                                               AchievementInitialized;                                   // 0x0130(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData05[0x3];                                       // 0x0131(0x0003) MISSED OFFSET
	int                                                Mystery2LastTime;                                         // 0x0134(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TMap<struct FString, struct FString>               ConfigStringMap;                                          // 0x0138(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<struct FString, int>                          ConfigIntMap;                                             // 0x0188(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<struct FString, float>                        ConfigFloatMap;                                           // 0x01D8(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<struct FString, bool>                         ConfigBoolMap;                                            // 0x0228(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<struct FString, int>                          UidAirDropTime;                                           // 0x0278(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	int                                                LoginFrequency;                                           // 0x02C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                CurrentDay;                                               // 0x02CC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TArray<struct FString>                             SecondLanguage;                                           // 0x02D0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	struct FDateTime                                   ShowSwitchSecondLanguageNextTime;                         // 0x02E0(0x0008) (Edit, BlueprintVisible, DisableEditOnInstance)
	TMap<struct FString, bool>                         HasClickInviteTeamAct;                                    // 0x02E8(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	int                                                CursorFaceInfoID;                                         // 0x0338(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData06[0x4];                                       // 0x033C(0x0004) MISSED OFFSET
	TMap<struct FString, struct FString>               FaceInfoClickedIDAndTime;                                 // 0x0340(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	bool                                               LanguagePromptState;                                      // 0x0390(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               HasTipLeagueGameSign;                                     // 0x0391(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData07[0x6];                                       // 0x0392(0x0006) MISSED OFFSET
	TMap<struct FString, int>                          ClickTimeHalloweenVehicle;                                // 0x0398(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<struct FString, bool>                         HasClickHalloweenExchange;                                // 0x03E8(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	struct FString                                     primeClicktimestamp;                                      // 0x0438(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	bool                                               isVNGadult;                                               // 0x0448(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData08[0x7];                                       // 0x0449(0x0007) MISSED OFFSET
	TMap<struct FString, int>                          ClickTimeIceLucky;                                        // 0x0450(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<struct FString, bool>                         HasCliickVehicleAcitivtyGuide;                            // 0x04A0(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<struct FString, int>                          ClickTimeAnniversary;                                     // 0x04F0(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	bool                                               haveClickGuaranteeTips;                                   // 0x0540(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData09[0x3];                                       // 0x0541(0x0003) MISSED OFFSET
	int                                                LastEnterExcitingTourTimeSec;                             // 0x0544(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               IfHasShowExcitingTourTips;                                // 0x0548(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData10[0x3];                                       // 0x0549(0x0003) MISSED OFFSET
	int                                                PrivacyPolicyPopupVersion;                                // 0x054C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass PlayerPrefs.PlayerPrefs_C");
		return pStaticClass;
	}


	void SetPopupPolicyVersion(int PolicyVersion);
	void SetGuaranteeFlag(bool clicked);
	void GetGuaranteeClickFlag(bool* clicked);
	void SetClickTimeAnniversary(const struct FString& UID, int Time);
	void GetClickTimeAnniversary(const struct FString& UID, int* Value);
	void GetCliickVehicleAcitivtyGuideExchange(const struct FString& Key, bool* hasClick);
	void SetCliickVehicleAcitivtyGuideExchange(const struct FString& Key, bool isClick);
	void SetClickTimeIceLucky(int Time, const struct FString& UUID);
	void GetClickTimeIceLucky(const struct FString& UUID, int* Value);
	void SetIsVNGAdult();
	void SetHasClickHalloweenExchange(bool isClick, const struct FString& UUID);
	void GetHasClickHalloweenExchange(const struct FString& UUID, bool* hasClick);
	void SetClickTimeHalloweenVehicle(int Time, const struct FString& UUID);
	void GetClickTimeHalloweenVehicle(const struct FString& UUID, int* Value);
	void GetFaceInfoClickedIDAndTime(const struct FString& Faceid, struct FString* TimeStamp);
	void SetFaceInfoClickedIDAndTime(const struct FString& Faceid);
	void GetCursorFaceInfoID(int* CursorFaceInfoID);
	void SetCursorFaceInfoID(int LastFace);
	void SetHasClickInviteTeamAct(bool isClick, const struct FString& UUID);
	void GetHasClickInviteTeamAct(const struct FString& UUID, bool* hasClick);
	void SetShowSwitchSecondLanguageNextTime(const struct FDateTime& DateTime);
	void GetShowSwitchSecondLanguageNextTime(struct FDateTime* DateTime);
	void GetLoginFrequency(int* loginfreq);
	void SetLoginFrequency(int CurrentDay);
	void GetAirDropTime(const struct FString& UID, int* outAirDropTime);
	void SetAirDropTime(int InTime, const struct FString& UID);
	void SetMystery2LastTime(int Time);
	void SetStoreGiftBoxList(TArray<int>* BoxList);
	void SetMallSeeDict(TMap<int, bool> Dict);
	void SetStoreBosList(TArray<int>* BoxList);
	void SetFirstEnterMall();
	void SetMysteryLastTime(int Time);
	void RejectUserAgreement();
	void AcceptUserAgreement(int newVersion);
	void ServerListClick();
	void HasCloseLocation(bool UID, bool* Has);
	void SetCloseLocation(bool CloseLocation, const struct FString& UID);
	void HasNearByNewTips(const struct FString& UID, bool* Has);
	void SetNearByNewTipsRead(const struct FString& UID);
	void SetYXXYRedPoint(int isRed);
	void AcceptGuestWarning();
	void RejectPolicy();
	void AcceptPolicy(int newVersion);
	void SetFirstInLobby();
	void SetTime(int arg);
	void ClearCount();
	void SetCount(int Count);
	class USaveGame* LoadData();
	void SaveData(bool* SaveDataState);
};


}

