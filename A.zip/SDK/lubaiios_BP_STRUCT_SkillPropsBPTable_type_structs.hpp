#pragma once

//    
// PUBGM 4.2.0 iOS
// 分享: - @lubaiios 
// 生成时间 2026年01月06日 16时15分13秒
namespace SDK
{
//---------------------By lubaiios @LBAsTool---------------------------
//Script Structs
//---------------------By lubaiios @LBAsTool---------------------------

// UserDefinedStruct BP_STRUCT_SkillPropsBPTable_type.BP_STRUCT_SkillPropsBPTable_type
// 0x0034
struct FBP_STRUCT_SkillPropsBPTable_type
{
	struct FString                                     Path_0_7125AC0045061D844040043E0816E498;                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     CName_1_638079C0129E37EF7ABD58DE018085B5;                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Wrapper_2_17D6010032F6D6462C8642BA064BF7A2;               // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_3_3E5DCC006BF812EC2517437F0C381754;                    // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

