#pragma once

//    
// PUBGM 4.2.0 iOS
// 分享: - @lubaiios 
// 生成时间 2026年01月06日 16时15分18秒
namespace SDK
{
//---------------------By lubaiios @LBAsTool---------------------------
//Script Structs
//---------------------By lubaiios @LBAsTool---------------------------

// UserDefinedStruct BP_STRUCT_DrinkCompoundConfig_type.BP_STRUCT_DrinkCompoundConfig_type
// 0x0068
struct FBP_STRUCT_DrinkCompoundConfig_type
{
	int                                                awardID_0_2BBEB1403F5A9B0B0EB1D00709609964;               // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                awardNum_1_37D1DA0026A0923C7757AA8B0609AE2D;              // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                descID_2_1FD235403A90703F024A7AEA0BB716C4;                // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ID_3_2F902D8037E77FA46237D6880B8119C4;                    // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                isMayCarry_4_2AB2AB40581603397B72EE3809C59429;            // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                JpKrAwardID_5_49A847000D2541FE5295535A097982A4;           // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                JpKrAwardNum_6_2ECC8FC045A856D735DAF8570798322D;          // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FString                                     Name_7_3AE82A806F13962C42B917EB011A5DB5;                  // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     solt_8_7F0FFAC007CB390F4285A58D011A9FB4;                  // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                EmoteID_9_4C84EC007C583218352536360B9EB844;               // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FString                                     PhizExplain_10_2575C54064E510CF536AC4300D724F0E;          // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     EmoteVoiceName_11_60ECC6803A15389C4AA097EC0673F2D5;       // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

